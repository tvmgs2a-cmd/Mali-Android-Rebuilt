# Mali source feature inventory

This inventory was extracted from the supplied `Mali-Android-3.1.2-fixed.zip` source and its `legacy-pwa/index.html` implementation.

| Source feature | Rebuilt implementation |
|---|---|
| Balance totals and month summary | Home screen |
| Income / expense / vehicle transactions | Transaction editor + Room |
| Create, edit, delete | Transaction editor and transaction rows |
| Search by note/category/type/date | History screen |
| Filter by type and month | History screen |
| Vehicle spend categories | Cars screen |
| Fuel litres and odometer | Fuel transaction fields |
| Fuel consumption, distance, cost/km | Cars screen + Finance domain |
| Per-month budget | Reports screen + Room |
| Expense category distribution | Reports screen + donut chart |
| JSON export | Reports screen + BackupCodec |
| JSON import / restore | Reports screen + BackupCodec; PWA v2 and native v3 supported |
| CSV export | Reports screen + CsvExporter |
| Delete all data | Reports screen with confirmation |
| Light/dark theme | Persisted preference |
| Optional biometric/device lock | AndroidX Biometric |
| Arabic RTL | App composition root |
| Offline/local-only storage | Room; no INTERNET permission |

Explicitly absent in the original source and therefore not invented here: user accounts, online login, cloud synchronization, and remote backup.

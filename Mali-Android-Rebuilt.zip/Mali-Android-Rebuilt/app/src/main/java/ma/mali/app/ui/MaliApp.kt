package ma.mali.app.ui

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.DirectionsCar
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ma.mali.app.data.TransactionEntity
import ma.mali.app.data.TxTypes
import ma.mali.app.domain.BackupCodec
import ma.mali.app.domain.BackupPayload
import ma.mali.app.domain.CsvExporter
import ma.mali.app.ui.components.TransactionEditorDialog
import ma.mali.app.ui.screens.CarsScreen
import ma.mali.app.ui.screens.HistoryScreen
import ma.mali.app.ui.screens.HomeScreen
import ma.mali.app.ui.screens.ReportsScreen
import ma.mali.app.ui.theme.MaliTheme
import java.time.LocalDate

private enum class MainTab(val label: String) {
    HOME("الرئيسية"), HISTORY("العمليات"), CARS("السيارة"), REPORTS("التقارير")
}

@Composable
fun MaliApp(
    isUnlocked: Boolean,
    biometricEnabled: Boolean,
    onUnlock: () -> Unit,
    onEnableBiometric: () -> Unit,
    onDisableBiometric: () -> Unit,
    vm: MaliViewModel = viewModel()
) {
    if (!isUnlocked) {
        MaliTheme(darkMode = false) {
            LockedScreen(onUnlock)
        }
        return
    }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val transactions by vm.transactions.collectAsStateWithLifecycle()
    val budgets by vm.budgets.collectAsStateWithLifecycle()
    val preferences = remember { context.getSharedPreferences("mali_preferences", Context.MODE_PRIVATE) }

    var darkMode by remember { mutableStateOf(preferences.getBoolean("dark_mode", false)) }
    var selectedTab by rememberSaveable { mutableStateOf(MainTab.HOME) }
    var showEditor by rememberSaveable { mutableStateOf(false) }
    var editorItem by remember { mutableStateOf<TransactionEntity?>(null) }
    var editorType by rememberSaveable { mutableStateOf(TxTypes.EXPENSE) }
    var deleteItem by remember { mutableStateOf<TransactionEntity?>(null) }
    var pendingDuplicateFuel by remember { mutableStateOf<TransactionEntity?>(null) }
    var pendingBackup by remember { mutableStateOf<BackupPayload?>(null) }
    var showSecurityDialog by remember { mutableStateOf(false) }

    val jsonExport = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            val transactionSnapshot = transactions.toList()
            val budgetSnapshot = budgets.toList()
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use {
                            it.write(BackupCodec.encode(transactionSnapshot, budgetSnapshot))
                        } ?: error("تعذر فتح الملف للتصدير")
                    }
                }
                toast(context, if (result.isSuccess) "تصدّرات النسخة الاحتياطية" else "فشل تصدير النسخة: ${result.exceptionOrNull()?.message}")
            }
        }
    }

    val csvExport = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) {
            val transactionSnapshot = transactions.toList()
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use {
                            it.write(CsvExporter.encode(transactionSnapshot))
                        } ?: error("تعذر فتح ملف CSV")
                    }
                }
                toast(context, if (result.isSuccess) "تصدّر ملف CSV" else "فشل التصدير: ${result.exceptionOrNull()?.message}")
            }
        }
    }

    val jsonImport = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val raw = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                        ?: error("تعذر قراءة الملف")
                    BackupCodec.decode(raw)
                }
            }
            result.onSuccess { payload -> pendingBackup = payload }
                .onFailure { toast(context, "الملف ماشي نسخة Mali صالحة: ${it.message}") }
        }
    }

    fun persistTransaction(item: TransactionEntity) {
        vm.saveTransaction(item) { result ->
            toast(context, if (result.isSuccess) "تحفظات العملية" else "تعذر حفظ العملية")
        }
    }

    MaliTheme(darkMode = darkMode) {
        androidx.compose.runtime.CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                topBar = {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        androidx.compose.foundation.layout.Box(
                            modifier = Modifier
                                .weight(0f)
                                .padding(end = 6.dp)
                        ) {
                            Text("م", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                        }
                        Column(Modifier.weight(1f)) {
                            Text("Mali", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                            Text("تدبير فلوسك بذكاء", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { showSecurityDialog = true }) {
                            Icon(Icons.Outlined.Lock, contentDescription = "الحماية")
                        }
                        IconButton(onClick = {
                            darkMode = !darkMode
                            preferences.edit().putBoolean("dark_mode", darkMode).apply()
                        }) {
                            Icon(if (darkMode) Icons.Outlined.LightMode else Icons.Outlined.DarkMode, contentDescription = "تغيير المظهر")
                        }
                    }
                },
                bottomBar = {
                    NavigationBar {
                        MainTab.entries.forEach { tab ->
                            val selected = selectedTab == tab
                            val icon = when (tab) {
                                MainTab.HOME -> Icons.Outlined.Home
                                MainTab.HISTORY -> Icons.Outlined.ReceiptLong
                                MainTab.CARS -> Icons.Outlined.DirectionsCar
                                MainTab.REPORTS -> Icons.Outlined.Assessment
                            }
                            NavigationBarItem(
                                selected = selected,
                                onClick = { selectedTab = tab },
                                icon = { Icon(icon, contentDescription = tab.label) },
                                label = { Text(tab.label) }
                            )
                        }
                    }
                }
            ) { innerPadding ->
                Column(Modifier.fillMaxSize().padding(innerPadding)) {
                    when (selectedTab) {
                        MainTab.HOME -> HomeScreen(
                            transactions = transactions,
                            budgets = budgets,
                            onAdd = { type -> editorType = type; editorItem = null; showEditor = true },
                            onHistory = { selectedTab = MainTab.HISTORY },
                            onEdit = { item -> editorItem = item; editorType = item.type; showEditor = true },
                            onDelete = { deleteItem = it }
                        )
                        MainTab.HISTORY -> HistoryScreen(
                            transactions = transactions,
                            onEdit = { item -> editorItem = item; editorType = item.type; showEditor = true },
                            onDelete = { deleteItem = it }
                        )
                        MainTab.CARS -> CarsScreen(
                            transactions = transactions,
                            onEdit = { item -> editorItem = item; editorType = item.type; showEditor = true },
                            onDelete = { deleteItem = it }
                        )
                        MainTab.REPORTS -> ReportsScreen(
                            transactions = transactions,
                            budgets = budgets,
                            onSaveBudget = { monthKey, amount ->
                                vm.saveBudget(monthKey, amount) { result ->
                                    toast(context, if (result.isSuccess) "تحفظات الميزانية" else "تعذر حفظ الميزانية")
                                }
                            },
                            onExportJson = { jsonExport.launch("mali-backup-${LocalDate.now()}.json") },
                            onExportCsv = { csvExport.launch("mali-operations-${LocalDate.now()}.csv") },
                            onImport = { jsonImport.launch(arrayOf("application/json", "text/json", "application/octet-stream")) },
                            onClearAll = {
                                vm.clearAll { result ->
                                    toast(context, if (result.isSuccess) "تم مسح جميع البيانات" else "تعذر مسح البيانات")
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    if (showEditor) {
        TransactionEditorDialog(
            initial = editorItem,
            initialType = editorType,
            onDismiss = { showEditor = false; editorItem = null },
            onSave = { item ->
                val hasDuplicateOdometer = item.type == TxTypes.FUEL && item.odoKm != null && transactions.any {
                    it.id != item.id && it.type == TxTypes.FUEL && it.odoKm == item.odoKm
                }
                if (hasDuplicateOdometer) pendingDuplicateFuel = item else persistTransaction(item)
                showEditor = false
                editorItem = null
            }
        )
    }

    deleteItem?.let { item ->
        AlertDialog(
            onDismissRequest = { deleteItem = null },
            title = { Text("حذف العملية؟") },
            text = { Text("واش متأكد بغيتي تمسح «${item.note}» بمبلغ ${ma.mali.app.domain.Finance.formatMoney(item.amountMinor)}؟") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteTransaction(item.id) { result ->
                        toast(context, if (result.isSuccess) "تم حذف العملية" else "تعذر حذف العملية")
                    }
                    deleteItem = null
                }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { deleteItem = null }) { Text("إلغاء") } }
        )
    }

    if (showSecurityDialog) {
        AlertDialog(
            onDismissRequest = { showSecurityDialog = false },
            title = { Text("حماية التطبيق") },
            text = {
                Text(
                    if (biometricEnabled) "قفل التطبيق مفعّل. كيطلب Mali التحقق بالبصمة أو رمز قفل الهاتف عند فتحه."
                    else "فعّل القفل باش تحمي واجهة التطبيق بالبصمة أو رمز قفل الهاتف."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showSecurityDialog = false
                    if (biometricEnabled) onDisableBiometric() else onEnableBiometric()
                }) { Text(if (biometricEnabled) "إيقاف الحماية" else "تفعيل القفل") }
            },
            dismissButton = { TextButton(onClick = { showSecurityDialog = false }) { Text("إلغاء") } }
        )
    }

    pendingDuplicateFuel?.let { item ->
        AlertDialog(
            onDismissRequest = { pendingDuplicateFuel = null },
            title = { Text("قراءة عداد مكررة") },
            text = { Text("كاينة تعبئة وقود أخرى بنفس قراءة العداد (${item.odoKm} كم). واش بغيتي تحفظ هاد العملية رغم ذلك؟") },
            confirmButton = {
                TextButton(onClick = { persistTransaction(item); pendingDuplicateFuel = null }) { Text("حفظ رغم ذلك") }
            },
            dismissButton = { TextButton(onClick = { pendingDuplicateFuel = null }) { Text("إلغاء") } }
        )
    }

    pendingBackup?.let { backup ->
        AlertDialog(
            onDismissRequest = { pendingBackup = null },
            title = { Text("استرجاع النسخة الاحتياطية") },
            text = {
                Text("هاد العملية غادي تعوّض البيانات الحالية بـ ${backup.transactions.size} عملية و${backup.budgets.size} ميزانية. صدّر نسخة من بياناتك الحالية قبل الاسترجاع إلا كنت محتاجها.")
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.replaceBackup(backup) { result ->
                        toast(context, if (result.isSuccess) "ترجعات البيانات بنجاح" else "تعذر استرجاع النسخة")
                    }
                    pendingBackup = null
                }) { Text("تعويض البيانات") }
            },
            dismissButton = { TextButton(onClick = { pendingBackup = null }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun LockedScreen(onUnlock: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Mali", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Black)
        Text("التطبيق محمي", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("أكد هويتك بالبصمة أو برمز قفل الهاتف للوصول إلى البيانات المالية.", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 12.dp))
        androidx.compose.material3.Button(onClick = onUnlock) { Text("فتح التطبيق") }
    }
}

private fun toast(context: Context, message: String) {
    Toast.makeText(context, message, Toast.LENGTH_LONG).show()
}

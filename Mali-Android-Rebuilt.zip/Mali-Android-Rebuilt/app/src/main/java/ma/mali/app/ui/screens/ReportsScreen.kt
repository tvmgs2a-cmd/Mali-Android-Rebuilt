package ma.mali.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import ma.mali.app.data.BudgetEntity
import ma.mali.app.data.TransactionEntity
import ma.mali.app.data.TxTypes
import ma.mali.app.domain.Finance
import ma.mali.app.ui.components.EmptyState
import ma.mali.app.ui.components.MoneyMiniCard
import ma.mali.app.ui.components.PanelCard
import ma.mali.app.ui.components.SectionTitle
import java.time.YearMonth

@Composable
fun ReportsScreen(
    transactions: List<TransactionEntity>,
    budgets: List<BudgetEntity>,
    onSaveBudget: (String, Long) -> Unit,
    onExportJson: () -> Unit,
    onExportCsv: () -> Unit,
    onImport: () -> Unit,
    onClearAll: () -> Unit
) {
    var selectedMonth by rememberSaveable { mutableStateOf(YearMonth.now().toString()) }
    var monthMenu by remember { mutableStateOf(false) }
    var budgetText by rememberSaveable { mutableStateOf("") }
    var showClearConfirm by remember { mutableStateOf(false) }
    var budgetError by remember { mutableStateOf<String?>(null) }
    val months = remember(transactions, budgets) {
        (transactions.map { it.date.take(7) } + budgets.map { it.monthKey } + YearMonth.now().toString())
            .distinct().sortedDescending()
    }
    val monthItems = Finance.month(transactions, selectedMonth)
    val totals = Finance.totals(monthItems)
    val currentBudget = budgets.firstOrNull { it.monthKey == selectedMonth }?.amountMinor ?: 0L
    val groupedExpenses = monthItems.filter { it.type != TxTypes.INCOME }
        .groupBy { if (TxTypes.isCar(it.type)) "مصاريف السيارات" else it.category.ifBlank { "أخرى" } }
        .mapValues { (_, items) -> items.sumOf { it.amountMinor } }
        .toList().sortedByDescending { it.second }

    Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("التقارير الشهرية", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("تحليل المداخيل والمصاريف والميزانية", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Box {
                OutlinedButton(onClick = { monthMenu = true }) { Text(selectedMonth) }
                DropdownMenu(expanded = monthMenu, onDismissRequest = { monthMenu = false }) {
                    months.forEach { month -> DropdownMenuItem(text = { Text(month) }, onClick = { selectedMonth = month; monthMenu = false }) }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MoneyMiniCard("المداخيل", totals.incomeMinor, Color(0xFF15956E), Modifier.weight(1f))
                    MoneyMiniCard("المصاريف", totals.expenseMinor, MaterialTheme.colorScheme.error, Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MoneyMiniCard("الصافي", totals.balanceMinor, modifier = Modifier.weight(1f))
                    Column(Modifier.weight(1f).background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(16.dp)).padding(12.dp)) {
                        Text("عدد العمليات", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(monthItems.size.toString(), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    }
                }
                SectionTitle("توزيع المصاريف")
                PanelCard {
                    if (groupedExpenses.isEmpty()) {
                        EmptyState("ما كايناش مصاريف فهاد الشهر.")
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            ExpenseDonut(groupedExpenses.map { it.second })
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                groupedExpenses.take(5).forEachIndexed { index, item ->
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(Modifier.size(9.dp).background(chartColor(index), CircleShape))
                                        Spacer(Modifier.size(7.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(item.first, style = MaterialTheme.typography.labelMedium, maxLines = 1)
                                            Text(Finance.formatMoney(item.second), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                            }
                        }
                        groupedExpenses.forEachIndexed { index, item ->
                            val total = groupedExpenses.sumOf { it.second }.coerceAtLeast(1L)
                            val percent = item.second.toDouble() / total * 100.0
                            Spacer(Modifier.height(10.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(item.first, style = MaterialTheme.typography.bodySmall)
                                Text("${Finance.formatNumber(percent, 1)}%", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            }
                            androidx.compose.material3.LinearProgressIndicator(
                                progress = { percent.toFloat().coerceIn(0f, 1f) },
                                modifier = Modifier.fillMaxWidth().height(6.dp),
                                color = chartColor(index),
                                trackColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                        }
                    }
                }
                SectionTitle("الميزانية الشهرية")
                PanelCard {
                    OutlinedTextField(
                        value = budgetText,
                        onValueChange = { budgetText = it; budgetError = null },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("الميزانية بالدرهم") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        placeholder = { Text(if (currentBudget > 0) Finance.formatMoney(currentBudget) else "مثلاً 5000") }
                    )
                    Button(
                        onClick = {
                            val amount = Finance.nonNegativeAmountToMinor(budgetText)
                            if (amount != null) {
                                onSaveBudget(selectedMonth, amount)
                                budgetText = ""
                                budgetError = null
                            } else {
                                budgetError = "دخل مبلغ صحيح، صفر أو أكثر"
                            }
                        },
                        modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
                    ) { Text("حفظ ميزانية $selectedMonth") }
                    budgetError?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                    Spacer(Modifier.height(14.dp))
                    Text("${Finance.formatMoney(totals.expenseMinor)} / ${if (currentBudget > 0) Finance.formatMoney(currentBudget) else "ما تحدداتش"}", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                    val ratio = if (currentBudget > 0) (totals.expenseMinor.toDouble() / currentBudget).coerceIn(0.0, 1.0).toFloat() else 0f
                    androidx.compose.material3.LinearProgressIndicator(
                        progress = { ratio }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp).height(8.dp),
                        color = if (currentBudget > 0 && totals.expenseMinor > currentBudget) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary
                    )
                    if (currentBudget > 0 && totals.expenseMinor > currentBudget) {
                        Text("تجاوزتي الميزانية بـ ${Finance.formatMoney(totals.expenseMinor - currentBudget)}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    } else if (currentBudget > 0) {
                        Text("باقي ${Finance.formatMoney(currentBudget - totals.expenseMinor)} من الميزانية", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    }
                }
                SectionTitle("النسخ الاحتياطي والبيانات")
                PanelCard {
                    Text("العمليات والميزانيات كتتحفظ محلياً فالهاتف. النسخ الاحتياطية JSON ما مشفّراش، لذلك خزنها فمكان آمن.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(onClick = onExportJson, modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) { Text("تصدير نسخة JSON") }
                    OutlinedButton(onClick = onExportCsv, modifier = Modifier.fillMaxWidth()) { Text("تصدير العمليات CSV") }
                    OutlinedButton(onClick = onImport, modifier = Modifier.fillMaxWidth()) { Text("استيراد نسخة JSON") }
                    OutlinedButton(
                        onClick = { showClearConfirm = true },
                        modifier = Modifier.fillMaxWidth(),
                        colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) { Text("مسح جميع البيانات") }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            title = { Text("مسح جميع البيانات؟") },
            text = { Text("غادي يتم حذف جميع العمليات والميزانيات نهائياً من هاد الهاتف. صدّر نسخة احتياطية قبل المتابعة إلا كنت محتاج البيانات.") },
            confirmButton = { TextButton(onClick = { showClearConfirm = false; onClearAll() }) { Text("مسح نهائياً", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { showClearConfirm = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun ExpenseDonut(values: List<Long>) {
    val total = values.sum().coerceAtLeast(1L)
    val colors = values.indices.map(::chartColor)
    Canvas(Modifier.size(142.dp)) {
        var start = -90f
        val stroke = Stroke(width = 28.dp.toPx(), cap = StrokeCap.Butt)
        values.forEachIndexed { index, value ->
            val sweep = (value.toFloat() / total.toFloat()) * 360f
            drawArc(
                color = colors[index], startAngle = start, sweepAngle = sweep,
                useCenter = false, style = stroke
            )
            start += sweep
        }
    }
}

private fun chartColor(index: Int): Color = listOf(
    Color(0xFF6259DF), Color(0xFF159B72), Color(0xFFD8952F), Color(0xFFDF5968),
    Color(0xFF398ACB), Color(0xFF9461B5), Color(0xFF4C9E9E)
)[index % 7]

package ma.mali.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import ma.mali.app.data.BudgetEntity
import ma.mali.app.data.MaliDatabase
import ma.mali.app.data.MaliRepository
import ma.mali.app.data.TransactionEntity
import ma.mali.app.domain.BackupPayload

class MaliViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = MaliRepository(MaliDatabase.getInstance(application))

    val transactions = repository.transactions.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList()
    )
    val budgets = repository.budgets.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList()
    )

    fun saveTransaction(item: TransactionEntity, onResult: (Result<Unit>) -> Unit = {}) {
        viewModelScope.launch {
            onResult(runCatching { repository.saveTransaction(item) })
        }
    }

    fun deleteTransaction(id: Long, onResult: (Result<Unit>) -> Unit = {}) {
        viewModelScope.launch {
            onResult(runCatching { repository.deleteTransaction(id) })
        }
    }

    fun saveBudget(monthKey: String, amountMinor: Long, onResult: (Result<Unit>) -> Unit = {}) {
        viewModelScope.launch {
            onResult(runCatching { repository.saveBudget(BudgetEntity(monthKey, amountMinor)) })
        }
    }

    fun replaceBackup(payload: BackupPayload, onResult: (Result<Unit>) -> Unit = {}) {
        viewModelScope.launch {
            onResult(runCatching { repository.replaceAll(payload.transactions, payload.budgets) })
        }
    }

    fun clearAll(onResult: (Result<Unit>) -> Unit = {}) {
        viewModelScope.launch {
            onResult(runCatching { repository.clearAll() })
        }
    }
}

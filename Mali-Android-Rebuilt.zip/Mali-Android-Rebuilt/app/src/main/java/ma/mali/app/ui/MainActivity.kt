package ma.mali.app.ui

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import java.util.concurrent.Executor

class MainActivity : FragmentActivity() {
    private val preferences by lazy { getSharedPreferences("mali_preferences", Context.MODE_PRIVATE) }
    private var isUnlocked by mutableStateOf(true)
    private var biometricEnabled by mutableStateOf(false)
    private var pendingSuccess: (() -> Unit)? = null
    private lateinit var biometricPrompt: BiometricPrompt

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        biometricEnabled = preferences.getBoolean("biometric_enabled", false)
        isUnlocked = !biometricEnabled

        val executor: Executor = ContextCompat.getMainExecutor(this)
        biometricPrompt = BiometricPrompt(
            this,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    pendingSuccess?.invoke()
                    pendingSuccess = null
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    pendingSuccess = null
                    if (errorCode !in setOf(
                            BiometricPrompt.ERROR_USER_CANCELED,
                            BiometricPrompt.ERROR_NEGATIVE_BUTTON,
                            BiometricPrompt.ERROR_CANCELED
                        )
                    ) {
                        Toast.makeText(this@MainActivity, "تعذر التحقق: $errString", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )

        setContent {
            MaliApp(
                isUnlocked = isUnlocked,
                biometricEnabled = biometricEnabled,
                onUnlock = { authenticate { isUnlocked = true } },
                onEnableBiometric = {
                    authenticate {
                        preferences.edit().putBoolean("biometric_enabled", true).apply()
                        biometricEnabled = true
                        isUnlocked = true
                        Toast.makeText(this, "تفعّلات الحماية", Toast.LENGTH_SHORT).show()
                    }
                },
                onDisableBiometric = {
                    authenticate {
                        preferences.edit().putBoolean("biometric_enabled", false).apply()
                        biometricEnabled = false
                        isUnlocked = true
                        Toast.makeText(this, "توقف قفل التطبيق", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }
    }

    private fun authenticate(onSuccess: () -> Unit) {
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_WEAK or
            BiometricManager.Authenticators.DEVICE_CREDENTIAL
        val availability = BiometricManager.from(this).canAuthenticate(authenticators)
        if (availability != BiometricManager.BIOMETRIC_SUCCESS) {
            val message = when (availability) {
                BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> "هاد الهاتف ما فيهش مستشعر بصمة متوافق."
                BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> "وسيلة التحقق ما متاحةش دابا."
                BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> "سجّل بصمة أو رمز قفل الهاتف من الإعدادات."
                else -> "الحماية البيومترية غير متاحة على هاد الجهاز."
            }
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
            return
        }
        pendingSuccess = onSuccess
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("حماية Mali")
            .setSubtitle("أكد هويتك بالبصمة أو برمز قفل الهاتف")
            .setAllowedAuthenticators(authenticators)
            .build()
        biometricPrompt.authenticate(info)
    }
}

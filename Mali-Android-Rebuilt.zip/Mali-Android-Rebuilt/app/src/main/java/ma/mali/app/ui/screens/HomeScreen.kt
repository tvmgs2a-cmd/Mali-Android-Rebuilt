package ma.mali.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ma.mali.app.data.BudgetEntity
import ma.mali.app.data.TransactionEntity
import ma.mali.app.data.TxTypes
import ma.mali.app.domain.Finance
import ma.mali.app.ui.components.BudgetProgress
import ma.mali.app.ui.components.EmptyState
import ma.mali.app.ui.components.MoneyMiniCard
import ma.mali.app.ui.components.PanelCard
import ma.mali.app.ui.components.SectionTitle
import ma.mali.app.ui.components.TransactionRow
import java.time.YearMonth

@Composable
fun HomeScreen(
    transactions: List<TransactionEntity>,
    budgets: List<BudgetEntity>,
    onAdd: (String) -> Unit,
    onHistory: () -> Unit,
    onEdit: (TransactionEntity) -> Unit,
    onDelete: (TransactionEntity) -> Unit
) {
    val currentMonth = YearMonth.now().toString()
    val monthItems = Finance.month(transactions, currentMonth)
    val allTotals = Finance.totals(transactions)
    val monthTotals = Finance.totals(monthItems)
    val budget = budgets.firstOrNull { it.monthKey == currentMonth }?.amountMinor ?: 0L

    Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp)) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(26.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
            Column(Modifier.padding(20.dp)) {
                Text("الرصيد الإجمالي", color = Color.White.copy(alpha = .82f), style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    Finance.formatMoney(allTotals.balanceMinor),
                    color = Color.White,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Black
                )
                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    BalanceCell("مجموع المداخيل", allTotals.incomeMinor, Modifier.weight(1f))
                    BalanceCell("مجموع المصاريف", allTotals.expenseMinor, Modifier.weight(1f))
                }
            }
        }

        SectionTitle("ملخص الشهر", currentMonth)
        PanelCard {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MoneyMiniCard("المداخيل", monthTotals.incomeMinor, Color(0xFF15956E), Modifier.weight(1f))
                MoneyMiniCard("المصاريف", monthTotals.expenseMinor, MaterialTheme.colorScheme.error, Modifier.weight(1f))
            }
            Spacer(Modifier.height(16.dp))
            BudgetProgress(monthTotals.expenseMinor, budget)
        }

        SectionTitle("إضافة سريعة", "اختار نوع العملية")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            QuickAction("مدخول", "＋", Modifier.weight(1f), Color(0xFF168B69)) { onAdd(TxTypes.INCOME) }
            QuickAction("مصروف", "−", Modifier.weight(1f), MaterialTheme.colorScheme.error) { onAdd(TxTypes.EXPENSE) }
            QuickAction("وقود", "⛽", Modifier.weight(1f), Color(0xFFB67A22)) { onAdd(TxTypes.FUEL) }
            QuickAction("صيانة", "⚙", Modifier.weight(1f), MaterialTheme.colorScheme.primary) { onAdd(TxTypes.MAINTENANCE) }
        }

        SectionTitle("آخر العمليات")
        PanelCard {
            val latest = transactions.take(5)
            if (latest.isEmpty()) EmptyState("مازال ما سجلتي حتى عملية. زيد أول عملية من الأزرار الفوق.")
            else latest.forEachIndexed { index, item ->
                if (index > 0) androidx.compose.material3.HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                TransactionRow(item, onEdit = { onEdit(item) }, onDelete = { onDelete(item) })
            }
        }
        TextButton(onClick = onHistory, modifier = Modifier.align(Alignment.CenterHorizontally)) {
            Text("عرض السجل كامل")
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun BalanceCell(title: String, amountMinor: Long, modifier: Modifier = Modifier) {
    Column(modifier.padding(12.dp)) {
        Text(title, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = .78f))
        Spacer(Modifier.height(5.dp))
        Text(Finance.formatMoney(amountMinor), style = MaterialTheme.typography.titleSmall, color = Color.White, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun QuickAction(label: String, icon: String, modifier: Modifier = Modifier, tint: Color, onClick: () -> Unit) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(17.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = 14.dp, horizontal = 3.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            Text(icon, color = tint, style = MaterialTheme.typography.titleLarge)
            Text(label, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
        }
    }
}

package ma.mali.app.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import ma.mali.app.data.TransactionEntity
import ma.mali.app.data.TxTypes
import ma.mali.app.domain.Finance
import java.time.LocalDate

private val transactionCategories = listOf(
    "عام", "الطعام", "النقل", "السكن", "الصحة", "التسوق", "الفواتير", "الراتب", "عمل إضافي", "أخرى"
)

@Composable
fun TransactionEditorDialog(
    initial: TransactionEntity?,
    initialType: String,
    onDismiss: () -> Unit,
    onSave: (TransactionEntity) -> Unit
) {
    var type by remember(initial?.id, initialType) { mutableStateOf(initial?.type ?: initialType) }
    var amount by remember(initial?.id) { mutableStateOf(initial?.let { "${it.amountMinor / 100}.${(it.amountMinor % 100).toString().padStart(2, '0')}" } ?: "") }
    var note by remember(initial?.id) { mutableStateOf(initial?.note.orEmpty()) }
    var category by remember(initial?.id) { mutableStateOf(initial?.category ?: when (initialType) {
        TxTypes.INCOME -> "الراتب"
        in TxTypes.car -> "النقل"
        else -> "عام"
    }) }
    var date by remember(initial?.id) { mutableStateOf(initial?.date ?: LocalDate.now().toString()) }
    var liters by remember(initial?.id) { mutableStateOf(initial?.liters?.toString().orEmpty()) }
    var odo by remember(initial?.id) { mutableStateOf(initial?.odoKm?.toString().orEmpty()) }
    var error by remember(initial?.id) { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "إضافة عملية" else "تعديل العملية", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) },
        text = {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 560.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(TxTypes.INCOME, TxTypes.EXPENSE).forEach { value ->
                        FilterChip(selected = type == value, onClick = { type = value }, label = { Text(TxTypes.label(value)) })
                    }
                }
                Text("مصاريف السيارة", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf(TxTypes.FUEL, TxTypes.MAINTENANCE, TxTypes.INSURANCE, TxTypes.CAR_OTHER).forEach { value ->
                        FilterChip(selected = type == value, onClick = { type = value }, label = { Text(when (value) {
                            TxTypes.FUEL -> "وقود"
                            TxTypes.MAINTENANCE -> "صيانة"
                            TxTypes.INSURANCE -> "تأمين"
                            else -> "أخرى"
                        }) })
                    }
                }
                OutlinedTextField(
                    value = amount, onValueChange = { amount = it; error = null },
                    modifier = Modifier.fillMaxWidth(), label = { Text("المبلغ بالدرهم") },
                    singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                OutlinedTextField(value = note, onValueChange = { note = it.take(90) }, modifier = Modifier.fillMaxWidth(), label = { Text("الوصف") }, singleLine = true)
                OutlinedTextField(value = category, onValueChange = { category = it.take(40) }, modifier = Modifier.fillMaxWidth(), label = { Text("التصنيف") }, singleLine = true)
                OutlinedTextField(
                    value = date, onValueChange = { date = it.take(10); error = null },
                    modifier = Modifier.fillMaxWidth(), label = { Text("التاريخ (YYYY-MM-DD)") }, singleLine = true
                )
                if (type == TxTypes.FUEL) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = liters, onValueChange = { liters = it }, modifier = Modifier.weight(1f),
                            label = { Text("اللترات") }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                        )
                        OutlinedTextField(
                            value = odo, onValueChange = { odo = it }, modifier = Modifier.weight(1f),
                            label = { Text("عداد km") }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                    }
                    Text("تسجيل قراءة العداد واللترات فكل تعبئة كيساعد على حساب الاستهلاك. الحساب تقديري وكيعتمد على تعبئات كاملة.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val amountMinor = Finance.amountToMinor(amount)
                val parsedDate = runCatching { LocalDate.parse(date) }.getOrNull()
                val parsedLiters = liters.trim().replace(',', '.').takeIf { it.isNotEmpty() }?.toDoubleOrNull()
                val parsedOdo = odo.trim().takeIf { it.isNotEmpty() }?.toLongOrNull()
                when {
                    amountMinor == null -> error = "دخل مبلغ صحيح أكبر من صفر"
                    parsedDate == null -> error = "التاريخ خاصو يكون بصيغة YYYY-MM-DD"
                    type == TxTypes.FUEL && liters.isNotBlank() && (parsedLiters == null || parsedLiters <= 0.0) -> error = "دخل عدد لترات صحيح"
                    type == TxTypes.FUEL && liters.isNotBlank() && parsedOdo == null -> error = "دخل قراءة عداد صحيحة مع اللترات"
                    type == TxTypes.FUEL && odo.isNotBlank() && (parsedOdo == null || parsedOdo <= 0L) -> error = "دخل قراءة عداد صحيحة"
                    else -> onSave(
                        TransactionEntity(
                            id = initial?.id ?: 0L,
                            type = type,
                            amountMinor = amountMinor,
                            note = note.trim().ifBlank { TxTypes.label(type) },
                            category = category.trim().ifBlank { "عام" },
                            date = parsedDate.toString(),
                            liters = if (type == TxTypes.FUEL) parsedLiters else null,
                            odoKm = if (type == TxTypes.FUEL) parsedOdo else null,
                            createdAt = initial?.createdAt ?: System.currentTimeMillis()
                        )
                    )
                }
            }) { Text(if (initial == null) "حفظ العملية" else "حفظ التعديلات") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

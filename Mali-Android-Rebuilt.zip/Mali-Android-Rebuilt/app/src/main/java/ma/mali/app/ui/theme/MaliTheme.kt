package ma.mali.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF5147C9),
    onPrimary = Color.White,
    secondary = Color(0xFF087C61),
    onSecondary = Color.White,
    background = Color(0xFFF4F5FA),
    onBackground = Color(0xFF1B2034),
    surface = Color.White,
    onSurface = Color(0xFF1B2034),
    surfaceVariant = Color(0xFFE9EAF3),
    onSurfaceVariant = Color(0xFF646B7E),
    error = Color(0xFFB3263E)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFB1A9FF),
    onPrimary = Color(0xFF201A63),
    secondary = Color(0xFF64D5B1),
    onSecondary = Color(0xFF00382C),
    background = Color(0xFF101522),
    onBackground = Color(0xFFEAF0FA),
    surface = Color(0xFF1A2232),
    onSurface = Color(0xFFEAF0FA),
    surfaceVariant = Color(0xFF293348),
    onSurfaceVariant = Color(0xFFADB8CC),
    error = Color(0xFFFF8290)
)

@Composable
fun MaliTheme(darkMode: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkMode) DarkColors else LightColors,
        content = content
    )
}

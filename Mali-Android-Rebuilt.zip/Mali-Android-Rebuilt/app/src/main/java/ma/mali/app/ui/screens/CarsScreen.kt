package ma.mali.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import ma.mali.app.data.TransactionEntity
import ma.mali.app.data.TxTypes
import ma.mali.app.domain.Finance
import ma.mali.app.ui.components.EmptyState
import ma.mali.app.ui.components.MoneyMiniCard
import ma.mali.app.ui.components.PanelCard
import ma.mali.app.ui.components.SectionTitle
import ma.mali.app.ui.components.TransactionRow

@Composable
fun CarsScreen(
    transactions: List<TransactionEntity>,
    onEdit: (TransactionEntity) -> Unit,
    onDelete: (TransactionEntity) -> Unit
) {
    val carItems = transactions.filter { TxTypes.isCar(it.type) }
    val totals = TxTypes.car.associateWith { type -> carItems.filter { it.type == type }.sumOf { it.amountMinor } }
    val fuelStats = Finance.fuelStats(carItems)

    Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        LazyColumn {
            item {
                PanelCard {
                    Text("مجموع مصاريف السيارة", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(5.dp))
                    Text(Finance.formatMoney(carItems.sumOf { it.amountMinor }), style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                }
                SectionTitle("التوزيع حسب النوع")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MoneyMiniCard("الوقود", totals[TxTypes.FUEL] ?: 0L, modifier = Modifier.weight(1f))
                    MoneyMiniCard("الصيانة", totals[TxTypes.MAINTENANCE] ?: 0L, modifier = Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MoneyMiniCard("التأمين والوثائق", totals[TxTypes.INSURANCE] ?: 0L, modifier = Modifier.weight(1f))
                    MoneyMiniCard("مصاريف أخرى", totals[TxTypes.CAR_OTHER] ?: 0L, modifier = Modifier.weight(1f))
                }
                SectionTitle("تحليل استهلاك الوقود")
                PanelCard {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FuelMetric("الاستهلاك", fuelStats.litersPer100Km?.let { "${Finance.formatNumber(it)} لتر/100كم" } ?: "—", Modifier.weight(1f))
                        FuelMetric("المسافة", if (fuelStats.distanceKm > 0) "${Finance.formatNumber(fuelStats.distanceKm.toDouble(), 0)} كم" else "—", Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FuelMetric("تكلفة الوقود", Finance.formatMoney(fuelStats.totalCostMinor), Modifier.weight(1f))
                        FuelMetric("تكلفة الكيلومتر", fuelStats.costPerKm?.let { "${Finance.formatNumber(it)} د.م" } ?: "—", Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        if (carItems.count { it.type == TxTypes.FUEL && (it.liters ?: 0.0) > 0 && (it.odoKm ?: 0L) > 0 } < 2)
                            "سجّل جوج تعبئات كاملة على الأقل، مع اللترات وقراءة العداد فكل مرة، باش يظهر حساب الاستهلاك."
                        else "الحساب تقديري: كيعتمد على المسافة بين قراءات العداد واللترات المسجلة فالتعبئات اللاحقة.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                SectionTitle("سجل مصاريف السيارة", "${carItems.size} عملية")
            }
            if (carItems.isEmpty()) {
                item { EmptyState("مازال ما سجلتي مصاريف السيارة.") }
            } else {
                items(carItems, key = { it.id }) { item ->
                    TransactionRow(item, onEdit = { onEdit(item) }, onDelete = { onDelete(item) })
                    androidx.compose.material3.HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun FuelMetric(title: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(4.dp))
        Text(value, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
    }
}

package ma.mali.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ma.mali.app.data.TransactionEntity
import ma.mali.app.data.TxTypes
import ma.mali.app.ui.components.EmptyState
import ma.mali.app.ui.components.TransactionRow

@Composable
fun HistoryScreen(
    transactions: List<TransactionEntity>,
    onEdit: (TransactionEntity) -> Unit,
    onDelete: (TransactionEntity) -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf("all") }
    var selectedMonth by rememberSaveable { mutableStateOf("all") }
    var monthMenu by remember { mutableStateOf(false) }
    val months = remember(transactions) { transactions.map { it.date.take(7) }.distinct().sortedDescending() }
    val filtered = transactions.filter { item ->
        val matchesType = when (filter) {
            "income" -> item.type == TxTypes.INCOME
            "expense" -> item.type == TxTypes.EXPENSE
            "car" -> TxTypes.isCar(item.type)
            else -> true
        }
        val matchesMonth = selectedMonth == "all" || item.date.startsWith(selectedMonth)
        val q = query.trim().lowercase()
        val matchesText = q.isBlank() || listOf(item.note, item.category, TxTypes.label(item.type), item.date)
            .any { it.lowercase().contains(q) }
        matchesType && matchesMonth && matchesText
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp)) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("قلب فالوصف أو التصنيف أو التاريخ") },
            singleLine = true
        )
        Row(
            Modifier.fillMaxWidth().padding(top = 9.dp).horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            listOf("all" to "الكل", "income" to "المداخيل", "expense" to "المصاريف", "car" to "السيارات").forEach { (key, label) ->
                FilterChip(selected = filter == key, onClick = { filter = key }, label = { Text(label) })
            }
        }
        OutlinedButton(onClick = { monthMenu = true }, modifier = Modifier.padding(top = 6.dp)) {
            Text(if (selectedMonth == "all") "جميع الشهور" else selectedMonth)
        }
        DropdownMenu(expanded = monthMenu, onDismissRequest = { monthMenu = false }) {
            DropdownMenuItem(text = { Text("جميع الشهور") }, onClick = { selectedMonth = "all"; monthMenu = false })
            months.forEach { month ->
                DropdownMenuItem(text = { Text(month) }, onClick = { selectedMonth = month; monthMenu = false })
            }
        }
        Text("${filtered.size} عملية", modifier = Modifier.padding(top = 5.dp, bottom = 4.dp), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (filtered.isEmpty()) {
            EmptyState("ما لقيت حتى عملية مطابقة للبحث أو التصفية.", Modifier.weight(1f))
        } else {
            LazyColumn(Modifier.weight(1f)) {
                items(filtered, key = { it.id }) { item ->
                    TransactionRow(item, onEdit = { onEdit(item) }, onDelete = { onDelete(item) })
                    androidx.compose.material3.HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                }
            }
        }
    }
}

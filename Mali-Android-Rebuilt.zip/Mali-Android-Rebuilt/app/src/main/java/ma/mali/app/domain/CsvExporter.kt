package ma.mali.app.domain

import ma.mali.app.data.TransactionEntity
import ma.mali.app.data.TxTypes

object CsvExporter {
    fun encode(items: List<TransactionEntity>): String = buildString {
        append('\uFEFF')
        appendLine(listOf("التاريخ", "النوع", "الوصف", "التصنيف", "المبلغ بالدرهم", "اللترات", "عداد الكيلومترات").joinToString(";") { cell(it) })
        items.forEach { item ->
            val amount = "%.2f".format(java.util.Locale.US, item.amountMinor / 100.0)
            val columns = listOf(
                item.date,
                TxTypes.label(item.type),
                item.note,
                item.category,
                amount,
                item.liters?.toString().orEmpty(),
                item.odoKm?.toString().orEmpty()
            )
            appendLine(columns.joinToString(";") { cell(it) })
        }
    }.removeSuffix("\n")

    private fun cell(value: String): String = "\"${value.replace("\"", "\"\"")}\""
}

package ma.mali.app.domain

import ma.mali.app.data.BudgetEntity
import ma.mali.app.data.TransactionEntity
import ma.mali.app.data.TxTypes
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth

 data class BackupPayload(
    val transactions: List<TransactionEntity>,
    val budgets: List<BudgetEntity>
)

object BackupCodec {
    fun encode(transactions: List<TransactionEntity>, budgets: List<BudgetEntity>): String {
        val txArray = JSONArray()
        transactions.forEach { item ->
            txArray.put(JSONObject().apply {
                put("id", item.id)
                put("type", item.type)
                put("amountMinor", item.amountMinor)
                put("amount", item.amountMinor / 100.0)
                put("note", item.note)
                put("category", item.category)
                put("date", item.date)
                put("liters", item.liters ?: JSONObject.NULL)
                put("odo", item.odoKm ?: JSONObject.NULL)
                put("createdAt", item.createdAt)
            })
        }
        val budgetArray = JSONArray()
        budgets.forEach { budget ->
            budgetArray.put(JSONObject().apply {
                put("monthKey", budget.monthKey)
                put("amountMinor", budget.amountMinor)
                put("updatedAt", budget.updatedAt)
            })
        }
        return JSONObject().apply {
            put("app", "Mali")
            put("schemaVersion", 4)
            put("exportedAt", Instant.now().toString())
            put("transactions", txArray)
            put("budgets", budgetArray)
        }.toString(2)
    }

    /** Reads the current native format and the legacy Mali PWA v2 JSON format. */
    fun decode(raw: String): BackupPayload {
        val root = JSONObject(raw)
        val txArray = root.optJSONArray("transactions")
            ?: throw IllegalArgumentException("ما لقيتش لائحة العمليات فالنسخة الاحتياطية")

        val seenIds = mutableSetOf<Long>()
        val transactions = buildList {
            for (index in 0 until txArray.length()) {
                val json = txArray.optJSONObject(index) ?: continue
                val type = json.optString("type", TxTypes.EXPENSE)
                    .takeIf { it in TxTypes.all } ?: continue

                val amountMinor = if (json.has("amountMinor") && !json.isNull("amountMinor")) {
                    json.optLong("amountMinor", 0L)
                } else {
                    runCatching {
                        java.math.BigDecimal(json.optString("amount", "0").replace(',', '.'))
                            .movePointRight(2).setScale(0, java.math.RoundingMode.HALF_UP).longValueExact()
                    }.getOrDefault(0L)
                }
                if (amountMinor <= 0L) continue

                val date = json.optString("date", LocalDate.now().toString())
                if (runCatching { LocalDate.parse(date) }.isFailure) continue

                val liters = if (json.has("liters") && !json.isNull("liters")) {
                    json.optDouble("liters").takeIf { it.isFinite() && it > 0.0 }
                } else null
                val odo = when {
                    json.has("odo") && !json.isNull("odo") -> json.optLong("odo").takeIf { it > 0L }
                    json.has("odoKm") && !json.isNull("odoKm") -> json.optLong("odoKm").takeIf { it > 0L }
                    else -> null
                }

                val importedId = json.optLong("id", 0L).takeIf { it > 0L && it !in seenIds }
                val safeId = importedId ?: (System.currentTimeMillis() + index).let { candidate ->
                    var unique = candidate
                    while (unique in seenIds) unique++
                    unique
                }
                seenIds += safeId

                add(
                    TransactionEntity(
                        id = safeId,
                        type = type,
                        amountMinor = amountMinor,
                        note = json.optString("note", TxTypes.label(type)).take(90),
                        category = json.optString("category", "عام").take(40),
                        date = date,
                        liters = liters,
                        odoKm = odo,
                        createdAt = json.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }
        }

        val budgetArray = root.optJSONArray("budgets")
        val budgets = if (budgetArray != null) {
            buildList {
                for (index in 0 until budgetArray.length()) {
                    val json = budgetArray.optJSONObject(index) ?: continue
                    val month = json.optString("monthKey")
                    val amount = json.optLong("amountMinor", 0L)
                    if (runCatching { YearMonth.parse(month) }.isSuccess && amount >= 0L) {
                        add(BudgetEntity(monthKey = month, amountMinor = amount))
                    }
                }
            }.distinctBy { it.monthKey }
        } else {
            // The PWA v2 format stored one shared budget for the current month.
            val oldBudget = runCatching {
                java.math.BigDecimal(root.optString("budget", "-1").replace(',', '.'))
                    .movePointRight(2).setScale(0, java.math.RoundingMode.HALF_UP).longValueExact()
            }.getOrDefault(-1L)
            if (oldBudget >= 0L) listOf(BudgetEntity(YearMonth.now().toString(), oldBudget)) else emptyList()
        }
        return BackupPayload(transactions, budgets)
    }
}

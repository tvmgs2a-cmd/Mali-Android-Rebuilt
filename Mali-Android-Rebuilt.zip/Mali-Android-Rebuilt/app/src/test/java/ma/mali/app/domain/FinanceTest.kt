package ma.mali.app.domain

import ma.mali.app.data.TransactionEntity
import ma.mali.app.data.TxTypes
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class FinanceTest {
    @Test
    fun balanceIncludesEveryExpenseType() {
        val items = listOf(
            tx(TxTypes.INCOME, 250_000),
            tx(TxTypes.EXPENSE, 40_000),
            tx(TxTypes.FUEL, 20_000),
            tx(TxTypes.MAINTENANCE, 15_000),
            tx(TxTypes.INSURANCE, 10_000),
            tx(TxTypes.CAR_OTHER, 5_000)
        )
        val totals = Finance.totals(items)
        assertEquals(250_000L, totals.incomeMinor)
        assertEquals(90_000L, totals.expenseMinor)
        assertEquals(160_000L, totals.balanceMinor)
    }

    @Test
    fun monthFilterUsesIsoYearMonthPrefix() {
        val items = listOf(
            tx(TxTypes.EXPENSE, 100, date = "2026-11-01"),
            tx(TxTypes.EXPENSE, 200, date = "2026-10-31"),
            tx(TxTypes.INCOME, 300, date = "2026-11-14")
        )
        assertEquals(2, Finance.month(items, "2026-11").size)
    }

    @Test
    fun fuelEfficiencyUsesRefillsAfterTheFirstFullTank() {
        val items = listOf(
            fuel(20_000, 50.0, 10_000),
            fuel(24_000, 48.0, 10_600),
            fuel(25_000, 50.0, 11_200)
        )
        val stats = Finance.fuelStats(items)
        assertEquals(1_200L, stats.distanceKm)
        assertEquals(98.0, stats.usedLiters, 0.0001)
        assertEquals(8.166666, stats.litersPer100Km!!, 0.0001)
        assertEquals(0.408333, stats.costPerKm!!, 0.0001)
    }

    @Test
    fun malformedOrNonPositiveAmountIsRejected() {
        assertNull(Finance.amountToMinor("abc"))
        assertNull(Finance.amountToMinor("0"))
        assertEquals(12_345L, Finance.amountToMinor("123,45"))
        assertEquals(12_346L, Finance.amountToMinor("123.455"))
    }

    @Test
    fun zeroBudgetIsAllowedButNegativeBudgetIsRejected() {
        assertEquals(0L, Finance.nonNegativeAmountToMinor("0"))
        assertEquals(125_000L, Finance.nonNegativeAmountToMinor("1250"))
        assertNull(Finance.nonNegativeAmountToMinor("-1"))
    }

    private fun tx(type: String, amount: Long, date: String = "2026-11-01") = TransactionEntity(
        type = type, amountMinor = amount, note = "test", category = "test", date = date
    )

    private fun fuel(amount: Long, liters: Double, odo: Long) = TransactionEntity(
        type = TxTypes.FUEL, amountMinor = amount, note = "fuel", category = "سيارة",
        date = "2026-11-01", liters = liters, odoKm = odo
    )
}

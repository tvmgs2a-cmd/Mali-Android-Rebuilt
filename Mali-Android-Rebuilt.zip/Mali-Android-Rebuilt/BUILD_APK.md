# Build Mali APK

## Android Studio

1. Extract this project folder.
2. Open the `Mali-Android-Rebuilt` directory in Android Studio.
3. Install Android SDK Platform 36 and Build Tools 36.0.0.
4. Select JDK 17 and sync Gradle. The included `gradlew` script downloads Gradle 8.13 from the official distribution host if Gradle is not already installed.
5. Run `./gradlew testDebugUnitTest`, then build the Debug APK.
6. Find the APK at `app/build/outputs/apk/debug/app-debug.apk`.

## GitHub Actions

The `.github/workflows/android.yml` workflow installs JDK 17, Android SDK 36 and Gradle 8.13, runs unit tests, builds the Debug APK and uploads `Mali-debug-apk` as a workflow artifact.

The artifact is a Debug APK for testing. A release APK for distribution requires a private signing key and a release-signing configuration supplied by the app owner.

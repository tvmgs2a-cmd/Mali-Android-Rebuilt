@echo off
setlocal
set GRADLE_VERSION=8.13
if not defined GRADLE_USER_HOME set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set GRADLE_HOME_DIR=%GRADLE_USER_HOME%\mali-wrapper\gradle-%GRADLE_VERSION%
set GRADLE_BIN=%GRADLE_HOME_DIR%\bin\gradle.bat
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  for /f "tokens=2" %%V in ('gradle --version ^| findstr /B /C:"Gradle "') do set INSTALLED_VERSION=%%V
  if "%INSTALLED_VERSION%"=="%GRADLE_VERSION%" (
    gradle %*
    exit /b %ERRORLEVEL%
  )
)
if not exist "%GRADLE_BIN%" (
  if not exist "%GRADLE_USER_HOME%\mali-wrapper" mkdir "%GRADLE_USER_HOME%\mali-wrapper"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%GRADLE_USER_HOME%\mali-wrapper\gradle-%GRADLE_VERSION%-bin.zip'; Expand-Archive -Force '%GRADLE_USER_HOME%\mali-wrapper\gradle-%GRADLE_VERSION%-bin.zip' '%GRADLE_USER_HOME%\mali-wrapper'; Remove-Item '%GRADLE_USER_HOME%\mali-wrapper\gradle-%GRADLE_VERSION%-bin.zip'"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_BIN%" %*
exit /b %ERRORLEVEL%
